<?php
require_once(__DIR__.'/src/config.php');
require_once(__DIR__.'/src/routes/Router.php');

unset($_SESSION["error"]);
unset($_SESSION["errors"]);

unset($_SESSION["success"]);
unset($_SESSION["success_message"]);
