<?php

// e check if unsa version 
phpinfo();
